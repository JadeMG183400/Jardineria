package sqlController;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public interface ISqlController {	
	
	public static Statement startConection(String user, String pass) {
		try {
			Statement st;
	        String url = "jdbc:mysql://localhost:3306/jardineria?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC"; 
	        Connection conn = DriverManager.getConnection(url,user,pass); 
	        st  = conn.createStatement();
	        return st;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	public static ResultSet executeViewQuery(String query,Statement st) {
		try {
			ResultSet rs = st.executeQuery(query);
			return rs;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;		
	}
	
	public static int executeDataManipulationQuery(String query,Statement st) {
		try {
			return st.executeUpdate(query);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}
	
	public static Statement closeConection(Statement st) {
		try {
			if(!st.isClosed()){
				st.close();
				
				return st;
			}
		} catch (Exception e) {
			
		}
		return st;
	}
}