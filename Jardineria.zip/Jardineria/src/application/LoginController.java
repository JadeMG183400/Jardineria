package application;


import java.io.IOException;
import java.net.URL;
import java.sql.Statement;
import java.util.ResourceBundle;

import Menu.MenuController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sqlController.ISqlController;
import alerts.*;

public class LoginController implements Initializable{
	@FXML
	Button btn_login;
	@FXML
	TextField txt_user;
	@FXML
	PasswordField txt_pass;
	
	private Statement st;
	
	@Override
	public void initialize(URL url, ResourceBundle rb) {
        String strPwd = "";
        txt_pass.setText(strPwd);
	}
	
	@FXML
	public void btn_loginOnAction(ActionEvent event) throws IOException{
		try{
			st =ISqlController.startConection(txt_user.getText(), txt_pass.getText());
			
			AnchorPane menu = (AnchorPane)FXMLLoader.load(getClass().getResource("/Menu/MenuFXML.fxml"));
			
			Scene sceneMenu = new Scene(menu);
			
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
			window.setScene(sceneMenu);
	        window.alwaysOnTopProperty();
	        window.setTitle("Menu");
	        window.getIcons().add(new Image("/application/icono.png"));
	        window.show();
	        
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
