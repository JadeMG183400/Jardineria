package TipoProducto;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class TipoProductoController {
	@FXML
	private Button btn_back;
	
	@FXML
	public void btn_backOnAction(ActionEvent event) throws IOException{
		AnchorPane menu = (AnchorPane)FXMLLoader.load(getClass().getResource("/Menu/MenuFXML.fxml"));
		
		Scene sceneMenu = new Scene(menu);
		
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(sceneMenu);
        window.alwaysOnTopProperty();
        window.setTitle("Menu");
        window.getIcons().add(new Image("/application/icono.png"));
        window.show();
	}
}
