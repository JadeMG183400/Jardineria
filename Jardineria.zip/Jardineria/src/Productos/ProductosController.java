package Productos;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sqlController.ISqlController;
import Productos.Product;
import Menu.*;
import alerts.AlertMessage;

public class ProductosController implements Initializable{
	private Statement st;
	private ResultSet rs;
	
	private int posicionEnTabla;
	private Button btn_producto,btn_add,btn_modify,btn_delete,btn_back;
	private ComboBox<String> combo_typeProduct;
	private ComboBox<String> combo_stateProduct;
	private TextField txt_name,txt_price;
	private TableView<Product> tbl_products;
	
	private ObservableList<Product> data = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Product,String> clm_name;
    @FXML 
    private TableColumn<Product,String> clm_type;
    @FXML
    private TableColumn<Product, String> clm_state;
    @FXML
    private TableColumn<Product,Double> clm_price;
    @FXML
    private TableColumn<Product,String> clm_date;

	
	public void setStatement(Statement st) {
		this.st = st;
	}
	
	@Override
    public void initialize(URL url, ResourceBundle rb) {
    	final ObservableList<Product> tblProductSelected = tbl_products.getSelectionModel().getSelectedItems();
    	tblProductSelected.addListener(selectorTablaProducto);
    	clm_name.setCellValueFactory(new PropertyValueFactory<>("name"));
    	clm_type.setCellValueFactory(new PropertyValueFactory<>("typeProduct"));
    	clm_price.setCellValueFactory(new PropertyValueFactory<>("price"));
    	clm_state.setCellValueFactory(new PropertyValueFactory<>("stateProduct"));
    	clm_date.setCellValueFactory(new PropertyValueFactory<>("ingressDate"));
        try {
            rs = ISqlController.executeViewQuery("SELECT * FROM productos ORDER BY id;", st);
        	while (rs.next()) {
				Product product = new Product(rs.getString("nombre"), rs.getString("tipo_producto"),rs.getString("estado_producto"), rs.getDouble("precio"), rs.getString("fecha_ingreso"));
				data.add(product);
        	}
        }catch (Exception e) {
        	System.out.println(e.getMessage());
        	AlertMessage.conectionAlert();
		}
        tbl_products.setItems(data);
    }
	
	@FXML
	public void btn_backOnAction(ActionEvent event) throws IOException{
		AnchorPane menu = (AnchorPane)FXMLLoader.load(getClass().getResource("/Menu/MenuFXML.fxml"));
		
		Scene sceneMenu = new Scene(menu);
		
		Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
		window.setScene(sceneMenu);
        window.alwaysOnTopProperty();
        window.setTitle("Menu");
        window.getIcons().add(new Image("/application/icono.png"));
        window.show();
	}
	
    private final ListChangeListener<Product> selectorTablaProducto =
            new ListChangeListener<Product>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends Product> c) {
                    ponerProductoSeleccionado();
                }
            };
            
     private void ponerProductoSeleccionado() {
    	 final Product producto = getTblProductoSeleccionado();
         posicionEnTabla = data.indexOf(producto);

         if (producto != null) {
        	 txt_name.setText(producto.getName());
        	 txt_price.setText(String.valueOf(producto.getPrice()));
         }     	
     }

     public Product getTblProductoSeleccionado() {
    	 if (tbl_products != null) {
    		 List<Product> tabla = tbl_products.getSelectionModel().getSelectedItems();
             if (tabla.size() == 1) {
            	 final Product competicionSeleccionada = tabla.get(0);
                 return competicionSeleccionada;
             }
         }
    	 return null;
     }
}
