package alerts;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.StageStyle;

public interface AlertMessage {
	
	public static void conectionAlert() {
		Alert alerta = new Alert(AlertType.WARNING);
    	alerta.setTitle("Error");
    	alerta.setContentText("Usuario o contrase�a incorrecta");
    	alerta.initStyle(StageStyle.UTILITY);
    	java.awt.Toolkit.getDefaultToolkit().beep();
    	alerta.showAndWait();
	}
	
	public static void duplicateRowAlert() {
		Alert alerta = new Alert(AlertType.WARNING);
    	alerta.setTitle("Error");
    	alerta.setHeaderText("Ya hay un registro similar en la base de datos");
    	alerta.initStyle(StageStyle.UTILITY);
    	java.awt.Toolkit.getDefaultToolkit().beep();
    	alerta.showAndWait();
	}
	
	public static void formatFieldAlert() {
		Alert alerta = new Alert(AlertType.WARNING);
    	alerta.setTitle("Error");
    	alerta.setContentText("Verifique los datos escritos en los campos");
    	alerta.initStyle(StageStyle.UTILITY);
    	java.awt.Toolkit.getDefaultToolkit().beep();
    	alerta.showAndWait();
	}
	
	public static void productNotFoundAlert() {
		Alert alerta = new Alert(AlertType.WARNING);
    	alerta.setTitle("Error");
    	alerta.setContentText("El producto que intenta a�adir no existe en la Base de Datos");
    	alerta.initStyle(StageStyle.UTILITY);
    	java.awt.Toolkit.getDefaultToolkit().beep();
    	alerta.showAndWait();
	}
	
	public static void notEnoughItems() {
		Alert alerta = new Alert(AlertType.WARNING);
    	alerta.setTitle("Error");
    	alerta.setContentText("No hay suficientes elementos en el inventario");
    	alerta.initStyle(StageStyle.UTILITY);
    	java.awt.Toolkit.getDefaultToolkit().beep();
    	alerta.showAndWait();
	}
	public static void payNotFound() {
		Alert alerta = new Alert(AlertType.WARNING);
    	alerta.setTitle("Error");
    	alerta.setContentText("Ponga una cantidad en el campo del pago");
    	alerta.initStyle(StageStyle.UTILITY);
    	java.awt.Toolkit.getDefaultToolkit().beep();
    	alerta.showAndWait();
	}
	public static void notEnoughMoney() {
		Alert alerta = new Alert(AlertType.WARNING);
    	alerta.setTitle("Error");
    	alerta.setContentText("No se puede pagar con esa cantidad");
    	alerta.initStyle(StageStyle.UTILITY);
    	java.awt.Toolkit.getDefaultToolkit().beep();
    	alerta.showAndWait();
	}
	
}
