package Menu;

import java.io.IOException;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MenuController {
	
	@FXML
	private Button btn_tipoProducto,btn_product,btn_fotografias,btn_riegos;
	
	Statement st;
	
	public void setStatement(Statement st) {
		this.st = st;
		System.out.println(st);
	}
	
	@FXML
	public void btn_tipoProductoOnAction(ActionEvent event) throws IOException{
		try{
			AnchorPane menu = (AnchorPane)FXMLLoader.load(getClass().getResource("/TipoProducto/TipoProductoFXML.fxml"));
			
			Scene sceneMenu = new Scene(menu);
			
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
			window.setScene(sceneMenu);
	        window.alwaysOnTopProperty();
	        window.setTitle("Type products");
	        window.getIcons().add(new Image("/application/icono.png"));
	        window.show();
	        
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void btn_productOnAction(ActionEvent event) throws IOException{
		try{
			AnchorPane menu = (AnchorPane)FXMLLoader.load(getClass().getResource("/Productos/ProductoFXML.fxml"));
			
			Scene sceneMenu = new Scene(menu);   
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
			window.setScene(sceneMenu);
			
	        window.alwaysOnTopProperty();
	        window.getIcons().add(new Image("/application/icono.png"));
	        window.setTitle("Products");
	        window.show();
	        
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void btn_fotografiasOnAction(ActionEvent event)throws IOException{
		try{
			AnchorPane menu = (AnchorPane)FXMLLoader.load(getClass().getResource("/Fotografias/FotografiasFXML.fxml"));
			
			Scene sceneMenu = new Scene(menu);
			
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
			window.setScene(sceneMenu);
	        window.alwaysOnTopProperty();
	        window.setTitle("Photos");
	        window.getIcons().add(new Image("/application/icono.png"));
	        window.show();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void btn_riegosOnAction(ActionEvent event) throws IOException{
		try{
			AnchorPane menu = (AnchorPane)FXMLLoader.load(getClass().getResource("/Riego/RiegoFXML.fxml"));
			
			Scene sceneMenu = new Scene(menu);
			
			Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
			window.setScene(sceneMenu);
	        window.alwaysOnTopProperty();
	        window.setTitle("Irrigation");
	        window.getIcons().add(new Image("/application/icono.png"));
	        window.show();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
